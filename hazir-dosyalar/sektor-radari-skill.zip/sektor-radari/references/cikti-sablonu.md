# Çıktı şablonu

Brifingi tam olarak bu düzende yaz.

---

**Sektör Radarı · [gün ay yıl]**
Tarama aralığı: son [96] saat · İncelenen haber: [sayı] · Rapora giren: [sayı]

**1. [Risk | Fırsat | İçerik fikri | Belirsiz] · [Tek cümlelik gelişme]**
- Bizim için anlamı: [Markaya etkisi, bir cümle]
- Önerilen aksiyon: [Bu hafta ne yapılmalı, bir cümle]
- Kaynak: [Site adı](link) · [haberin tarihi]

**2. ...**

---

**Sorum:** [Brifingi iyileştirecek tek soru. Soracak bir şey yoksa bu satırı yazma.]

---

Kurallar:
- Maddeleri önem sırasına diz; en acil risk en üstte.
- "Bizim için anlamı" satırında genel laf yok; markanın adını, ürününü ya da gündemini an.
- Tarih yoksa "tarih yok" yaz ve maddeyi Belirsiz yap.
