---
name: sektor-radari
description: Sektör haberlerini tarar, markayı etkileyenleri fırsat, risk, içerik fikri veya belirsiz diye ayırır, kaynaklı kısa brifing yazar. "Radarı çalıştır" denince kullan.
---

# Sektör Radarı

Bu skill, bir markanın sektöründeki güncel haberleri tarar ve yalnızca o markanın bu hafta bir karar ya da aksiyon alabileceği gelişmeleri raporlar. Amaç haber özeti değil, karar brifingidir.

## Ne zaman kullanılır

- Kullanıcı "radarı çalıştır", "sektör radarı", "bugünün brifingi", "sektörde ne var" dediğinde.
- Zamanlanmış bir görev bu skill'i çağırdığında.

## Girdiler

Önce projedeki dosyaları oku. Bunlar yoksa kullanıcıya sor, tahmin etme.

1. `marka-profili.md`: marka, ürünler, hedef kitle, bu dönemin gündemi (lansman, fiyat, kampanya).
2. `rakipler.md`: izlenecek rakipler ve sektör oyuncuları.
3. `kaynaklar.md`: öncelikli haber siteleri ve arama konuları.

Kullanıcı bir zaman aralığı söylemediyse **son 96 saat** geçerlidir.

## Adımlar

1. **Bağlamı topla.** Üç dosyayı oku. Bu dönemin gündemini (lansman, fiyat, kampanya) bir cümleyle not et; her haberi buna göre değerlendireceksin.
2. **Tara.** Web aramasıyla `kaynaklar.md`'deki konuları ve rakipleri ara. Öncelikli siteler için `site:` ile arama yap. En az 6, en fazla 12 arama yap.
3. **Ele.** Şu soruyu sor: "Bu haber, bu markanın bu hafta bir kararını değiştirebilir mi?" Cevap hayırsa haberi at. Genel trend yazıları, tarihi belirsiz içerikler ve basın bülteni tekrarları elenir.
4. **Doğrula.** Kalan her haberin linkini aç. Haberin tarihi, kaynağı ve iddiası sayfada gerçekten var mı kontrol et. Açılmayan ya da tarihi bulunmayan haberi ya at ya da **Belirsiz** olarak işaretle.
5. **Sınıflandır.** Her maddeyi tek bir etiketle işaretle:
   - **Risk**: markaya maliyet, itibar ya da pazar payı kaybı getirebilir.
   - **Fırsat**: markanın hızlı davranırsa kazanabileceği bir açıklık.
   - **İçerik fikri**: iletişim ekibinin kullanabileceği bir gündem.
   - **Belirsiz**: önemli olabilir ama kanıt eksik.
6. **Yaz.** `references/cikti-sablonu.md`'deki biçimi kullan.

## Kriter

- Her madde bu hafta bir karara ya da aksiyona dönüşebilmeli.
- Madde sayısını doldurmak için zayıf haber ekleme. Az ama sağlam madde, çok ama boş maddeden iyidir.
- Rakip haberlerinde "bu bizim için ne demek?" sorusunu mutlaka cevapla.

## Çıktı

- En fazla 5 madde.
- Her madde: etiket, tek cümlelik gelişme, markaya etkisi, önerilen aksiyon, kaynak linki, haberin tarihi.
- Sonda en fazla 1 soru: brifingi daha iyi yapmak için kullanıcıdan eksik olan bilgi.

## Kısıtlar

- Haberde olmayan rakamı, tarihi ya da iddiayı ekleme.
- Emin değilsen "Belirsiz" yaz ve nedenini söyle.
- Linki açamadığın bir haberi doğrulanmış gibi sunma.
- Hiç uygun haber yoksa bunu açıkça söyle: "Son 96 saatte markanızı etkileyen bir gelişme bulamadım." Boş brifing, uydurma brifingden iyidir.
- Eksik bilgi varsa sor.
